const RESOURCE_PAGE_CONFIG = {
  guru: {
    resource: "guru",
    title: "Data Guru",
    fields: [
      { key: "nip", label: "NIP" },
      { key: "nama", label: "Nama" },
      { key: "nama_pelajaran_badges", label: "Mata Pelajaran", isHtml: true },
      { key: "kelas_list_badges", label: "Kelas Diampu", isHtml: true },
    ],
    addModal: "tambahGuruModal",
    editModal: "editGuruModal",
    deleteModal: "hapusGuruModal",
  },
  kelas: {
    resource: "kelas",
    title: "Data Kelas",
    fields: [{ key: "jenjang", label: "Jenjang" }, { key: "nama_kelas", label: "Nama Kelas" }],
    addModal: "tambahKelasModal",
    editModal: "editKelasModal",
    deleteModal: "hapusKelasModal",
  },
  pelajaran: {
    resource: "pelajaran",
    title: "Data Pelajaran",
    fields: [{ key: "nama_pelajaran", label: "Nama Pelajaran" }],
    addModal: "tambahPelajaranModal",
    editModal: "editPelajaranModal",
    deleteModal: "hapusPelajaranModal",
  },
  tahun: {
    resource: "tahun",
    title: "Data Tahun Ajaran",
    fields: [{ key: "tahun_ajaran", label: "Tahun Ajaran" }],
    addModal: "tambahTahunModal",
    editModal: "editTahunModal",
    deleteModal: "hapusTahunModal",
  },
};

document.addEventListener("DOMContentLoaded", () => {
  const config = RESOURCE_PAGE_CONFIG[document.body.dataset.supabaseResource];
  if (!config) return;

  const table = document.getElementById("dataTable");
  const tableBody = table?.querySelector("tbody");
  const cardBody = table?.closest(".card")?.querySelector(".card-body");
  if (!table || !tableBody || !cardBody) return;

  const status = document.createElement("div");
  status.id = "supabaseStatus";
  status.className = "small text-muted mb-2";
  status.setAttribute("role", "status");
  cardBody.insertBefore(status, cardBody.firstChild);

  const addModal = document.getElementById(config.addModal);
  const editModal = document.getElementById(config.editModal);
  const deleteModal = document.getElementById(config.deleteModal);
  const addForm = addModal?.querySelector("form");
  const editForm = editModal?.querySelector("form");
  const deleteForm = deleteModal?.querySelector("form");
  const importForm = addModal?.querySelectorAll("form")[1];
  let dataTable = null;
  let records = [];

  if (window.jQuery?.fn?.DataTable?.isDataTable(table)) {
    window.jQuery(table).DataTable().destroy();
  }
  tableBody.replaceChildren();

  function setStatus(message, isError = false, isDebug = false) {
    if (isDebug && !isError) return;
    status.textContent = message;
    status.classList.toggle("text-danger", isError);
    status.classList.toggle("text-muted", !isError);
  }

  function addFormError(form, message) {
    let error = form.querySelector(".api-error");
    if (!error) {
      error = document.createElement("div");
      error.className = "api-error text-danger small mt-2";
      error.setAttribute("role", "alert");
      form.append(error);
    }
    error.textContent = message;
  }

  function formValues(form) {
    const data = {};
    const elements = form.querySelectorAll("input[name], select[name], textarea[name]");
    elements.forEach((el) => {
      data[el.name] = el.value.trim();
    });
    return data;
  }

  function hideModal(modalId) {
    window.jQuery(`#${modalId}`).modal("hide");
  }

  function renderRows() {
    if (dataTable) {
      dataTable.destroy();
      dataTable = null;
    } else if (window.jQuery?.fn?.DataTable?.isDataTable(table)) {
      window.jQuery(table).DataTable().destroy();
    }
    tableBody.replaceChildren();

    records.forEach((record, index) => {
      if (config.resource === "guru") {
        const mapels = record.nama_pelajaran_list && record.nama_pelajaran_list.length
          ? record.nama_pelajaran_list
          : (record.nama_pelajaran && record.nama_pelajaran !== "-" ? [record.nama_pelajaran] : []);
        record.nama_pelajaran_badges = mapels.length
          ? mapels.map((m) => `<span class="badge badge-primary mr-1 mb-1 font-weight-normal">${m}</span>`).join("")
          : '<span class="text-muted small">Belum diatur</span>';

        const kelasList = Array.isArray(record.kelas_list) ? record.kelas_list : [];
        record.kelas_list_badges = kelasList.length
          ? kelasList.map((k) => `<span class="badge badge-success mr-1 mb-1 font-weight-normal">${k}</span>`).join("")
          : '<span class="text-muted small">Belum diatur</span>';
      }

      const row = document.createElement("tr");
      const numberCell = document.createElement("td");
      numberCell.textContent = String(index + 1);
      row.append(numberCell);

      config.fields.forEach(({ key, isHtml }) => {
        const cell = document.createElement("td");
        if (config.resource === "kelas" && key === "nama_kelas") {
          const button = document.createElement("button");
          button.type = "button";
          button.className = "btn btn-link p-0 text-left";
          button.textContent = record[key] ?? "";
          button.setAttribute("aria-label", `Lihat siswa kelas ${record[key] ?? ""}`);
          button.dataset.recordAction = "students";
          button.dataset.recordId = record.id;
          cell.append(button);
        } else if (isHtml) {
          cell.innerHTML = record[key] ?? "";
        } else {
          cell.textContent = record[key] ?? "";
        }
        row.append(cell);
      });

      const actions = document.createElement("td");
      const rowActions = [
        { action: "edit", label: "Edit", style: "warning", target: config.editModal },
        { action: "delete", label: "Hapus", style: "danger", target: config.deleteModal },
      ];
      if (config.resource === "guru") {
        rowActions.push({ action: "reset-password", label: "Reset Password", style: "info" });
      }
      if (config.resource === "kelas") {
        rowActions.unshift({ action: "wali-kelas", label: "Wali Kelas", style: "success", target: "waliKelasModal" });
      }
      rowActions.forEach(({ action, label, style, target }) => {
        const button = document.createElement("button");
        button.type = "button";
        button.className = `btn btn-sm btn-${style} mr-1`;
        button.textContent = label;
        button.dataset.recordAction = action;
        button.dataset.recordId = record.id;
        if (target) {
          button.dataset.toggle = "modal";
          button.dataset.target = `#${target}`;
        }
        actions.append(button);
      });
      row.append(actions);
      tableBody.append(row);
    });

    if (window.jQuery?.fn?.DataTable) {
      dataTable = window.jQuery(table).DataTable({
        pageLength: 10,
        language: {
          search: "Cari:",
          lengthMenu: "Tampilkan _MENU_ entri",
          info: "Menampilkan _START_ sampai _END_ dari _TOTAL_ entri",
          infoEmpty: "Tidak ada data untuk ditampilkan",
          zeroRecords: "Data tidak ditemukan",
          paginate: { first: "Awal", last: "Akhir", next: "Berikutnya", previous: "Sebelumnya" },
        },
        drawCallback: function () {
          const page = this.api().page.info();
          this.api().column(0, { page: "current" }).nodes().each((cell, index) => {
            cell.textContent = String(page.start + index + 1);
          });
        },
      });
    }
  }

  let cachedSubjects = [];
  let cachedClasses = [];

  function renderGuruCheckboxes(containerPelajaranId, containerKelasId, selectedPIds = [], selectedClasses = []) {
    const pContainer = document.getElementById(containerPelajaranId);
    const kContainer = document.getElementById(containerKelasId);

    const safePIds = (selectedPIds || []).map(Number);
    const safeClasses = (selectedClasses || []).map((c) => String(c).trim());

    if (pContainer) {
      if (!cachedSubjects.length) {
        pContainer.innerHTML = '<span class="text-muted small">Belum ada data mata pelajaran.</span>';
      } else {
        pContainer.innerHTML = cachedSubjects.map((s) => {
          const isChecked = safePIds.includes(Number(s.id));
          return `
            <div class="custom-control custom-checkbox custom-control-inline mr-3 mb-1">
              <input type="checkbox" class="custom-control-input" id="${containerPelajaranId}_${s.id}" value="${s.id}" ${isChecked ? "checked" : ""}>
              <label class="custom-control-label small" for="${containerPelajaranId}_${s.id}">${s.nama_pelajaran}</label>
            </div>
          `;
        }).join("");
      }
    }

    if (kContainer) {
      if (!cachedClasses.length) {
        kContainer.innerHTML = '<span class="text-muted small">Belum ada data kelas aktif.</span>';
      } else {
        kContainer.innerHTML = cachedClasses.map((c) => {
          const isChecked = safeClasses.includes(String(c.nama_kelas).trim());
          return `
            <div class="custom-control custom-checkbox custom-control-inline mr-3 mb-1">
              <input type="checkbox" class="custom-control-input" id="${containerKelasId}_${c.id}" value="${c.nama_kelas}" ${isChecked ? "checked" : ""}>
              <label class="custom-control-label small" for="${containerKelasId}_${c.id}">${c.nama_kelas}</label>
            </div>
          `;
        }).join("");
      }
    }
  }

  async function loadResourceSelectOptions() {
    if (config.resource === "guru") {
      try {
        const [resPelajaran, resKelas] = await Promise.all([
          apiGet("/data/pelajaran").catch(() => ({ data: [] })),
          apiGet("/data/kelas").catch(() => ({ data: [] })),
        ]);
        cachedSubjects = resPelajaran.data || [];
        cachedClasses = resKelas.data || [];

        renderGuruCheckboxes("tambahGuruPelajaranList", "tambahGuruKelasList");
        renderGuruCheckboxes("editGuruPelajaranList", "editGuruKelasList");

        const setupToggleAll = (btnId, containerId) => {
          const btn = document.getElementById(btnId);
          if (btn && !btn.dataset.wired) {
            btn.dataset.wired = "true";
            btn.addEventListener("click", () => {
              const checks = Array.from(document.querySelectorAll(`#${containerId} input[type="checkbox"]`));
              const allChecked = checks.length > 0 && checks.every((c) => c.checked);
              checks.forEach((c) => (c.checked = !allChecked));
              btn.textContent = allChecked ? "Pilih Semua" : "Batal Pilih";
            });
          }
        };

        setupToggleAll("btnToggleAllPelajaranTambah", "tambahGuruPelajaranList");
        setupToggleAll("btnToggleAllKelasTambah", "tambahGuruKelasList");
        setupToggleAll("btnToggleAllPelajaranEdit", "editGuruPelajaranList");
        setupToggleAll("btnToggleAllKelasEdit", "editGuruKelasList");
      } catch (err) {
        console.warn("Gagal memuat opsi pelajaran & kelas:", err);
      }
    }
  }

  async function loadRecords() {
    if (!(await window.adminSessionReady)) {
      setStatus(window.adminSessionError || "Sesi admin diperlukan.", true);
      return;
    }
    setStatus("Memuat data dari Supabase...", false, true);
    try {
      await loadResourceSelectOptions();
      const result = await apiGet(`/data/${config.resource}`);
      records = result.data || [];
      renderRows();
      setStatus(`${records.length} data dimuat.`, false, true);
    } catch (error) {
      setStatus(error.message, true);
    }
  }

  tableBody.addEventListener("click", async (event) => {
    const button = event.target.closest("[data-record-action]");
    if (!button) return;
    const record = records.find((item) => String(item.id) === button.dataset.recordId);
    if (!record) return;

    if (button.dataset.recordAction === "students") {
      const modal = document.getElementById("lihatSiswaKelasModal");
      const studentBody = document.getElementById("siswaKelasBody");
      const studentStatus = document.getElementById("siswaKelasStatus");
      if (!modal || !studentBody || !studentStatus) return;

      const classLabel = [record.jenjang, record.nama_kelas].filter(Boolean).join(" - ");
      document.getElementById("lihatSiswaKelasTitle").textContent = `Siswa Kelas ${classLabel}`;
      studentBody.replaceChildren();
      studentStatus.textContent = "Memuat daftar siswa...";
      window.jQuery("#lihatSiswaKelasModal").modal("show");
      try {
        const result = await apiGetClassStudents(record.id);
        result.data.forEach((student, index) => {
          const row = document.createElement("tr");
          [index + 1, student.nis, student.nama].forEach((value) => {
            const cell = document.createElement("td");
            cell.textContent = String(value ?? "");
            row.append(cell);
          });
          studentBody.append(row);
        });
        studentStatus.textContent = result.data.length
          ? `${result.data.length} siswa terhubung ke kelas ini.`
          : "Belum ada siswa yang terhubung ke kelas ini.";
      } catch (error) {
        studentStatus.textContent = error.message;
      }
    } else if (button.dataset.recordAction === "wali-kelas") {
      const kelasId = record.kelas_id ?? record.id;
      const namaKelas = record.nama_kelas ?? "";
      const kelasIdInput = document.getElementById("waliKelasKelasId");
      const classYearIdInput = document.getElementById("waliKelasClassYearId");
      const kelasNamaInput = document.getElementById("waliKelasKelasNama");
      const guruSelect = document.getElementById("waliKelasGuru");
      const tahunSelect = document.getElementById("waliKelasTahun");
      if (kelasIdInput) kelasIdInput.value = String(kelasId);
      if (classYearIdInput) classYearIdInput.value = String(record.id);
      if (kelasNamaInput) kelasNamaInput.value = namaKelas;
      if (guruSelect) guruSelect.value = "";
      if (tahunSelect) tahunSelect.value = String(window.activeAcademicYear?.id || "");
      if (typeof loadWaliKelasOptions === "function") {
        loadWaliKelasOptions();
      }
      if (typeof loadWaliKelasByClass === "function") {
        loadWaliKelasByClass(kelasId);
      }
      window.jQuery("#waliKelasModal").modal("show");
    } else if (button.dataset.recordAction === "edit") {
      editForm.dataset.recordId = record.id;
      const elements = editForm.querySelectorAll("input[name], select[name], textarea[name]");
      elements.forEach((el) => {
        if (record[el.name] !== undefined && record[el.name] !== null) {
          el.value = record[el.name];
        } else {
          el.value = "";
        }
      });
      if (config.resource === "guru") {
        renderGuruCheckboxes("editGuruPelajaranList", "editGuruKelasList", record.pelajaran_ids, record.kelas_list);
      }
    } else if (button.dataset.recordAction === "reset-password") {
      const confirmReset = window.confirm(
        `Reset password akun guru "${record.nama}" (NIP: ${record.nip}) ke password default (NIP)?\n\nKlik OK untuk mereset.`
      );
      if (!confirmReset) return;

      try {
        setStatus(`Mereset password guru ${record.nama}...`, false, true);
        if (typeof apiAdminResetGuruPassword === "function") {
          await apiAdminResetGuruPassword(record.nip);
        } else {
          const client = getSupabaseClient();
          const { error } = await client.rpc("admin_set_guru_password", {
            p_nip: String(record.nip).trim(),
            p_new_password: String(record.nip).trim(),
          });
          if (error) throw error;
        }
        window.alert(`Password guru "${record.nama}" berhasil direset ke default (NIP: ${record.nip}).`);
        setStatus(`Password ${record.nama} berhasil direset ke default.`, false, true);
      } catch (err) {
        window.alert(`Gagal mereset password: ${err.message}`);
        setStatus(err.message, true);
      }
    } else {
      deleteForm.dataset.recordId = record.id;
      const message = deleteForm.querySelector("p");
      if (message) message.textContent = `Yakin ingin menghapus data ${config.title.toLowerCase()} ini?`;
    }
  });

  addForm?.addEventListener("submit", async (event) => {
    event.preventDefault();
    try {
      const payload = formValues(addForm);
      if (config.resource === "guru") {
        const pChecks = Array.from(addForm.querySelectorAll("#tambahGuruPelajaranList input[type='checkbox']:checked"));
        payload.pelajaran_ids = pChecks.map((c) => Number(c.value));
        const kChecks = Array.from(addForm.querySelectorAll("#tambahGuruKelasList input[type='checkbox']:checked"));
        payload.kelas_list = kChecks.map((c) => c.value);
      }
      await apiPost(`/data/${config.resource}`, payload);
      addForm.reset();
      hideModal(config.addModal);
      await loadRecords();
    } catch (error) {
      addFormError(addForm, error.message);
    }
  });

  editForm?.addEventListener("submit", async (event) => {
    event.preventDefault();
    try {
      const payload = formValues(editForm);
      if (config.resource === "guru") {
        const pChecks = Array.from(editForm.querySelectorAll("#editGuruPelajaranList input[type='checkbox']:checked"));
        payload.pelajaran_ids = pChecks.map((c) => Number(c.value));
        const kChecks = Array.from(editForm.querySelectorAll("#editGuruKelasList input[type='checkbox']:checked"));
        payload.kelas_list = kChecks.map((c) => c.value);
      }
      await apiPut(`/data/${config.resource}/${encodeURIComponent(editForm.dataset.recordId)}`, payload);
      hideModal(config.editModal);
      await loadRecords();
    } catch (error) {
      addFormError(editForm, error.message);
    }
  });

  deleteForm?.addEventListener("submit", async (event) => {
    event.preventDefault();
    try {
      await apiDelete(`/data/${config.resource}/${encodeURIComponent(deleteForm.dataset.recordId)}`);
      hideModal(config.deleteModal);
      await loadRecords();
    } catch (error) {
      addFormError(deleteForm, error.message);
    }
  });

  importForm?.addEventListener("submit", async (event) => {
    event.preventDefault();
    const file = importForm.querySelector('input[type="file"]')?.files[0];
    try {
      if (!file) throw new Error("Pilih file Excel terlebih dahulu.");
      if (!window.XLSX) throw new Error("Library Excel gagal dimuat.");
      const workbook = window.XLSX.read(await file.arrayBuffer(), { type: "array" });
      const sheet = workbook.Sheets[workbook.SheetNames[0]];
      const rows = window.XLSX.utils.sheet_to_json(sheet, { range: 1, defval: "" });
      const result = await apiImport(config.resource, rows);
      importForm.reset();
      hideModal(config.addModal);
      await loadRecords();
      setStatus(`${result.imported} data diimpor; ${result.skipped} duplikat dilewati.`);
    } catch (error) {
      addFormError(importForm, error.message);
    }
  });

  loadRecords();
});